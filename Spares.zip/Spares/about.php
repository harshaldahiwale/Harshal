<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<section class="about">

   <div class="row">

      <div class="box">
         <img src="images/spares.jpg" alt="">
         <h3>Shop Online Spares</h3>
         <p>An Overview, here study the meaning of OnlineShopping, Process, Merits and Demerits and Future Status of Online Shopping in India. Online shopping of spare parts of motorcycle is the activity or action of buying products or services over the Internet.  </p>
         <a href="contact.php" class="btn">contact us</a>
      </div>

      <div class="box">
         <img src="images/about-img-2.jpg" alt="">
         <h3>Motorcycle spare shops</h3>
         <p>The Spare parts stores industry includes stores / shops that retail new and used automotive parts and accessories, repair automobiles and install automotive accessories. Spares parts stores can be found in all parts of the world as long as there are automobiles there.</p>
         <a href="shop.php" class="btn">our shop</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">clients reivews</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/pic-1.png" alt="">
         <p>Thank you for taking your time to provide us an inspiring rating. We are gratified to hear that you were satisfied with our customer service.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Roshan Garg</h3>
      </div>

      <div class="box">
         <img src="images/pic-2.png" alt="">
         <p>Thank you for the awesome review! Provide you with the excellent experience with all our customers is the best thing Thank you for choosing Spares.com.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Amina Vyas</h3>
      </div>

      <div class="box">
         <img src="images/pic-3.png" alt="">
         <p>Thank you for taking your time to provide us an inspiring rating. We are glad to hear that you were satisfied with the quality of service we are providing to our customers. </p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Dev Singh</h3>
      </div>

      <div class="box">
         <img src="images/pic-4.png" alt="">
         <p>We are happy to hear that what you wanted out of your car part-buying experience with us at Spares.com. We look forward to doing business with you again soon!

Regards,</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Nalini Shah</h3>
      </div>

      <div class="box">
         <img src="images/pic-5.png" alt="">
         <p>Thank you for taking your time to provide us an inspiring rating. We are glad to hear that you were satisfied with the quality of service we are providing to our customers.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Jignesh Rane</h3>
      </div>

      <div class="box">
         <img src="images/pic-6.png" alt="">
         <p>Thank you for taking your time to provide us an inspiring rating. We are gratified to hear that you were satisfied with our customer service.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Natasha Gour</h3>
      </div>

   </div>

</section>









<?php include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>