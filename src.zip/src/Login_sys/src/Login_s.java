import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import registration.Newproject;
import registration.connection;
public class Login_s extends JFrame{

	private JFrame frame;
	private JTextField username;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login_s window = new Login_s();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login_s() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 569, 419);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setFont(new Font("Engravers MT", Font.PLAIN, 35));
		lblNewLabel.setBounds(174, 23, 187, 48);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Lucida Sans", Font.BOLD, 22));
		lblNewLabel_1.setBounds(64, 107, 120, 28);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Lucida Sans", Font.BOLD, 22));
		lblNewLabel_2.setBounds(64, 188, 118, 28);
		frame.getContentPane().add(lblNewLabel_2);
		
		username = new JTextField();
		username.setFont(new Font("Calibri", Font.PLAIN, 20));
		username.setBounds(184, 101, 218, 34);
		frame.getContentPane().add(username);
		username.setColumns(10);
		
		password = new JPasswordField();
		password.setFont(new Font("Calibri", Font.PLAIN, 20));
		password.setBounds(184, 188, 218, 34);
		frame.getContentPane().add(password);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String pass = password.getText();
				String user = username.getText();
				try {
				Connection con = connection.getCon();
				Statement st = con.createStatement();
				
	            ResultSet rs;
				
					rs = st.executeQuery("select * from login where username='"+user+"' and password='"+pass+"';");
				
	            if(rs.next())
	            {
//				if(pass.contains("Hd427@18")user.contains("harshald98")) {
//					password.setText(null);
//					username.setText(null);
					
					Newproject info = new Newproject();
					Newproject.main(null);
					
				}else {
					JOptionPane.showMessageDialog(null, "Invalid Login Details", "Login Errors",JOptionPane.ERROR_MESSAGE);
					password.setText(null);
					username.setText(null);
				}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 18));
		btnNewButton.setBounds(43, 289, 100, 39);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				username.setText(null);
				password.setText(null);
			}
		});
		btnReset.setFont(new Font("Arial", Font.BOLD, 18));
		btnReset.setBounds(224, 289, 100, 39);
		frame.getContentPane().add(btnReset);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frame = new JFrame();
				if(JOptionPane.showConfirmDialog(frame,"Confirm, if you want to exit",
						"Login", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}				
			}
		});
		btnExit.setFont(new Font("Arial", Font.BOLD, 18));
		btnExit.setBounds(407, 289, 100, 39);
		frame.getContentPane().add(btnExit);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(30, 253, 477, 2);
		frame.getContentPane().add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(30, 81, 477, 2);
		frame.getContentPane().add(separator_1);
	}
}
