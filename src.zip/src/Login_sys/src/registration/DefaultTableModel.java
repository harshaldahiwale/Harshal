package registration;

public class DefaultTableModel {

	public void setColumnIdentifiers(Object[] column) {
		// TODO Auto-generated method stub
		
	}

}
