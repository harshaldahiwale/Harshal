package registration;

import java.awt.EventQueue;

import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.TableModel;
import javax.swing.border.EtchedBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import registration.connection;

public class Newproject extends JFrame {

	private JFrame frame;
	private JTextField id;
	private JTextField firstname;
	private JTextField cont;
	private JTextField course;
	private JTable table;
	private JTextField address;
	private JTextField lastname;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Newproject window = new Newproject();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Newproject() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1004, 755);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("STUDENT REGISTRATION SYSTEM");
		lblNewLabel.setForeground(new Color(186, 85, 211));
		lblNewLabel.setBackground(new Color(0, 255, 255));
		lblNewLabel.setFont(new Font("Lucida Sans", Font.BOLD, 40));
		lblNewLabel.setBounds(129, 49, 727, 60);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(224, 255, 255));
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(25, 168, 351, 523);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Student ID");
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_2.setBounds(10, 24, 104, 30);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("First Name");
		lblNewLabel_2_1.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_2_1.setBounds(10, 72, 104, 30);
		panel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("Contact");
		lblNewLabel_2_2.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_2_2.setBounds(10, 233, 104, 30);
		panel.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_2_3 = new JLabel("Course");
		lblNewLabel_2_3.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_2_3.setBounds(10, 284, 104, 30);
		panel.add(lblNewLabel_2_3);
		
		id = new JTextField();
		id.setFont(new Font("Calibri", Font.PLAIN, 18));
		id.setBounds(124, 21, 217, 28);
		panel.add(id);
		id.setColumns(10);
		
		firstname = new JTextField();
		firstname.setFont(new Font("Calibri", Font.PLAIN, 18));
		firstname.setColumns(10);
		firstname.setBounds(124, 69, 217, 28);
		panel.add(firstname);
		
		cont = new JTextField();
		cont.setFont(new Font("Calibri", Font.PLAIN, 18));
		cont.setColumns(10);
		cont.setBounds(124, 233, 217, 28);
		panel.add(cont);
		
		course = new JTextField();
		course.setFont(new Font("Calibri", Font.PLAIN, 18));
		course.setColumns(10);
		course.setBounds(124, 286, 217, 28);
		panel.add(course);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try{
	                Connection con = connection.getCon();
	                Statement st = con.createStatement();
	                int sid=Integer.parseInt(id.getText());
	                String Firstname=firstname.getText();
	                String Lastname=lastname.getText();
	                String Address=address.getText();
	                int Contact=Integer.parseInt(cont.getText());
	                String Course=course.getText();
	                st.executeUpdate("insert into register values("+sid+",'"+Firstname+"','"+Lastname+"','"+Address+"',"+Contact+",'"+Course+"')");
	                JOptionPane.showMessageDialog(null,"Student Added Successfully");
	                
	            }
	           catch(Exception ee)
	           {
	                JOptionPane.showMessageDialog(null,ee);
	           }
				
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				model.addRow(new Object[] {
						id.getText(),
						firstname.getText(),
						lastname.getText(),
						address.getText(),												
						cont.getText(),
						course.getText(),					
				});
				
				if(table.getSelectedRow() == -1) {
					if(table.getRowCount() == 0) {
						JOptionPane.showMessageDialog(null, "Student Update Confirmed","Student Registration System",
								JOptionPane.OK_OPTION);
					}
				}
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.BOLD, 18));
		btnNewButton.setBounds(29, 338, 121, 44);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				if(table.getSelectedRow() == -1) {
					if(table.getRowCount() == 0) {
						JOptionPane.showMessageDialog(null, "No data to delete","Student Registration System",
								JOptionPane.OK_OPTION);
					}else {
						JOptionPane.showMessageDialog(null, "Select a row to delete","Student Registration System",
								JOptionPane.OK_OPTION);
				}
				}else {
					model.removeRow(table.getSelectedRow());
						
					}
				
				
			}
		});
		btnNewButton_1.setFont(new Font("Arial", Font.BOLD, 18));
		btnNewButton_1.setBounds(29, 403, 121, 44);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Reset");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				id.setText("");
				firstname.setText("");
				lastname.setText("");
				address.setText("");												
				cont.setText("");
				course.setText("");				
				
			}
		});
		btnNewButton_2.setFont(new Font("Arial", Font.BOLD, 18));
		btnNewButton_2.setBounds(201, 338, 121, 44);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Print");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					table.print();
				}
				catch(java.awt.print.PrinterException e) {
					System.err.format("No Printer Found", e.getMessage());
				}
			}
		});
		btnNewButton_3.setFont(new Font("Arial", Font.BOLD, 18));
		btnNewButton_3.setBounds(201, 403, 121, 44);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_3_1 = new JButton("Exit");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frame = new jframe();
				if(JOptionPane.showConfirmDialog(frame,"Confirm, if you want to exit",
						"Student Registration System", JOptionPane.YES_NO_OPTION)==JOptionPane.YES_NO_OPTION) {
					System.exit(0);
				}				
			}
		});
		btnNewButton_3_1.setFont(new Font("Arial", Font.BOLD, 18));
		btnNewButton_3_1.setBounds(107, 469, 121, 44);
		panel.add(btnNewButton_3_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Address");
		lblNewLabel_2_1_1.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_2_1_1.setBounds(10, 179, 104, 30);
		panel.add(lblNewLabel_2_1_1);
		
		address = new JTextField();
		address.setFont(new Font("Calibri", Font.PLAIN, 18));
		address.setColumns(10);
		address.setBounds(124, 181, 217, 28);
		panel.add(address);
		
		lastname = new JTextField();
		lastname.setFont(new Font("Calibri", Font.PLAIN, 18));
		lastname.setColumns(10);
		lastname.setBounds(124, 128, 217, 28);
		panel.add(lastname);
		
		JLabel lblNewLabel_2_1_2 = new JLabel("Last Name");
		lblNewLabel_2_1_2.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_2_1_2.setBounds(10, 126, 104, 30);
		panel.add(lblNewLabel_2_1_2);
		
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(386, 168, 582, 523);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Student ID", "First Name", "Last Name", "Address", "Contact", "Course"
			}
		));
		
		
		scrollPane.setViewportView(table);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(176, 224, 230));
		panel_1.setBounds(25, 10, 943, 148);
		frame.getContentPane().add(panel_1);
		
	}
}
