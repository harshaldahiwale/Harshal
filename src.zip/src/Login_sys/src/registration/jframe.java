package registration;

import javax.swing.JFrame;

public class jframe extends JFrame {

}
